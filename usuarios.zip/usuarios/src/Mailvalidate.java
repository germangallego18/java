/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 *
 * @author GFG
 */
public class Mailvalidate {
String mail ;
    public void setMail(String mail) {
        this.mail = mail;
    }
    
 
    
    
    
    
    
    public  boolean validacion(){
boolean ok=false;
Pattern pattern = Pattern
                .compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
Matcher mather = pattern.matcher(this.mail);
 
        if (mather.find() == true) {
            System.out.println("El email ingresado es válido.");
        ok=true;
        } else {
            System.out.println("El email ingresado es inválido.");
        ok=false;
        }
   return ok;
    
    }
 


}
    
    
    
    
    
    

