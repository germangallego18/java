
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author GFG
 */
public class conexionlocal {

    public static String URL = "jdbc:mysql://localhost:3306/usuarios";
    public static String USERNAME = "root";
    public static String PASSWORD = "";
    boolean conecto = false;
    Connection con = null;
//////////////////////CONEXION LOCAL///////////////////////////
    public  Connection getConection() {
                      
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.print( "Conexion Exitosa!");
       conecto = true;
        } catch (Exception e) {
            System.out.print( "No se pudo conectar " + e);
              
        }

        return con;
    }

  boolean conecto (){


return conecto;
  }
}