
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author GFG
 */
public class Enviamail {
String nombre,correo,contrasena;
  
boolean enviado = false;  public boolean isEnviado() {
        return enviado;
    }

    public void setEnviado(boolean enviado) {
        this.enviado = enviado;
    }
    
   
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
    public void Sendmail(){   
    try {
            Properties props = new Properties();
            props.setProperty("mail.smtp.host", "smtp.gmail.com");
            props.setProperty("mail.smtp.starttls.enable", "true");
            props.setProperty("mail.smtp.port", "587");
            props.setProperty("mail.smtp.auth", "true");

            Session session = Session.getDefaultInstance(props);

            String correoRemitente = "gfgcorp20@gmail.com";
            String passwordRemitente = "1234569877z*";
            String correoReceptor = correo;
            String asunto = "Recuperacion de Cuenta";
            String mensaje = "Hola<br>Esta es la informacion del usuario.</b>"+"<br>"+"Usuario: "+nombre+"</b>"+"<br>"+"Contraseña: "+contrasena+"</b>";
                    //+"   <a href=\"http://gfgcorp.blogspot.com/\">\n" +
//"    <img src=\"https://gfgcorp.000webhostapp.com/Logo2.png\"\n" +
//"    width=\"300\" height=\"100\"\n" +
//"    alt=\"Clic para visitar el blog!!\" />\n" +
//"</a>";

            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(correoRemitente));

            message.addRecipient(Message.RecipientType.TO, new InternetAddress(correoReceptor));
            message.setSubject(asunto);
            message.setText(mensaje, "ISO-8859-1", "html");

            Transport t = session.getTransport("smtp");
            t.connect(correoRemitente, passwordRemitente);
            t.sendMessage(message, message.getRecipients(Message.RecipientType.TO));
            t.close();
            enviado = true;
            JOptionPane.showMessageDialog(null, "Correo Electronico Enviado");

        } catch (AddressException ex) {
            Logger.getLogger(Enviamail.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(Enviamail.class.getName()).log(Level.SEVERE, null, ex);
        }

    }                         

}